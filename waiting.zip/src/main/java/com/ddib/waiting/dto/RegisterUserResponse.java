package com.ddib.waiting.dto;

public record RegisterUserResponse(Long rank) {
}
