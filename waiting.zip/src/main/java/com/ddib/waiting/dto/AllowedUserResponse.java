package com.ddib.waiting.dto;

public record AllowedUserResponse(Boolean allowed) {
}
