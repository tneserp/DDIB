package com.ddib.waiting.dto;

public record RankNumberResponse(Long rank) {
}
