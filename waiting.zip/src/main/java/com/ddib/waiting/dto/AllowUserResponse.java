package com.ddib.waiting.dto;

public record AllowUserResponse(Long requestCount, Long allowedCount) {
}