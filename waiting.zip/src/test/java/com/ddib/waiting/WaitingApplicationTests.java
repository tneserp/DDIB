package com.ddib.waiting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaitingApplicationTests {

	@Test
	void contextLoads() {
	}

}
