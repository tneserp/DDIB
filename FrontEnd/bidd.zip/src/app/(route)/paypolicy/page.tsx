export default function PayPolicy() {
  return <div>가격정책</div>;
}
