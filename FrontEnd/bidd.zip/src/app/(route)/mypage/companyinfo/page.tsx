import SellerInfo from "./_components/SellerInfo";

export default function CompanyInfo() {
  return (
    <div>
      <SellerInfo />
    </div>
  );
}
